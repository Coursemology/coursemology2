# return True if you want the test to pass
# each test passes in the test type and a number
def test_result(test_types, numbers):
    return True
