def solve():
    pass
