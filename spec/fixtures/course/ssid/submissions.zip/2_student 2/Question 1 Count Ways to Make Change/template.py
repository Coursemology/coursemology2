def count_ways_to_make_change(amount):
    # Implement recursively
    coins = [100, 50, 20, 10, 5, 1] 
    return count_change(amount, coins, 0)
    
def count_change(amount, coins, index):
    if amount == 0:
        return 1
    elif amount < 0 or index >= len(coins):
        return 0
    else:
        return count_change(amount - coins[index], coins, index) + count_change(amount, coins, index + 1)