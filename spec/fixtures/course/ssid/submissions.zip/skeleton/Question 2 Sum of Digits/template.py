def sum_of_digits(n):
    # Implement the sum of digits using recursion
    return 0
