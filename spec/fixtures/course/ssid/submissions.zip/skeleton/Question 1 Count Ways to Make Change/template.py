def count_ways_to_make_change(amount):
    # Implement recursively
    return 0
