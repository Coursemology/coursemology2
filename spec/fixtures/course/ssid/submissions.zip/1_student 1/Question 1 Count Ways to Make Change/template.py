def count_ways_to_make_change(amount):
    # Implement recursively
    # Add comment
    # WHOAMI
    # Comment
    coins = [1, 5, 10, 20, 50, 100]
    def count_helper(amount, index) :
        if amount == 0 :
            return 1
        elif amount < 0 or len(coins) == index :
            return 0
        else :
            return count_helper(amount - coins[index], index) + count_helper(amount, index + 1)
    return count_helper(amount, 0)