def to_rna(your_args_here):
    """Your code here"""

def is_same_dogma(your_args_here):
    """Your code here"""
