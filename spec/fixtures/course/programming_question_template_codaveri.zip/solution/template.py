### DO NOT CHANGE THE CODE IN THIS BOX ##################################
                                                                        #
put_op("to_dna", ("dna",), lambda x: x)                                 #
put_op("to_dna", ("rna",), reverse_transcribe)                          #
put_op("to_rna", ("dna",), transcribe)                                  #
put_op("to_rna", ("rna",), lambda x: x)                                 #
put_op("is_same_dogma", ("dna","dna"), lambda x, y: x == y)             #
put_op("is_same_dogma", ("dna","rna"), lambda x, y: transcribe(x) == y) #
put_op("is_same_dogma", ("rna","dna"), lambda x, y: x == transcribe(y)) #
put_op("is_same_dogma", ("rna","rna"), lambda x, y: x == y)             #
                                                                        #
def to_dna(tagged_data):                                                #
    tag_type = get_tag_type(tagged_data)                                #
    data     = get_data(tagged_data)                                    #
    op       = get_op("to_dna", (tag_type,))                            #
    return tag("dna", op(data))                                         #
                                                                        #
### DO NOT CHANGE THE CODE IN THIS BOX ##################################

# [Marking Scheme]
# 3 marks for to_rna
#   +1 keeps Tagged-Data abstraction, uses get_tag_type/get_data
#   +1 keeps OPERATION_TABLE abstraction, uses get_op
#   +1 returns a correctly tagged Tagged-Data object
# 3 marks for is_same_dogma
#   +2 both abstractions as above
#   +1 returns a boolean
# Total: 6 marks
# Note: Do not double-deduct breaking of abstraction for each ADT

def to_rna(tagged_data):
    tag_type = get_tag_type(tagged_data)
    data     = get_data(tagged_data)
    op       = get_op("to_rna", (tag_type,))
    return tag("rna", op(data))

def is_same_dogma(tagged_data1, tagged_data2):
    tag_type1 = get_tag_type(tagged_data1)
    tag_type2 = get_tag_type(tagged_data2)
    op        = get_op("is_same_dogma", (tag_type1, tag_type2))
    data1     = get_data(tagged_data1)
    data2     = get_data(tagged_data2)
    return op(data1, data2)
