
tagged_dna1 = tag("dna", "AAATGC")
tagged_rna1 = tag("rna", "GCAUUU")
tagged_dna2 = tag("dna", "TTACAT")
tagged_rna2 = tag("rna", "AUGUAA")


