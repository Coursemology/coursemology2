import unittest
# Needs xmlrunner: pip install unittest-xml-reporting
import xmlrunner
import sys

class PublicTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }
    def test_public_01(self):
        self.meta['expression'] = "get_data(to_rna(tagged_dna1))"
        self.meta['expected'] = "'GCAUUU'"
        
        _out = get_data(to_rna(tagged_dna1))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, 'GCAUUU')
    def test_public_02(self):
        self.meta['expression'] = "get_data(to_rna(tagged_rna1))"
        self.meta['expected'] = "'GCAUUU'"
        
        _out = get_data(to_rna(tagged_rna1))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, 'GCAUUU')
    def test_public_03(self):
        self.meta['expression'] = "is_same_dogma(tagged_dna1, tagged_rna1)"
        self.meta['expected'] = str(True)
        
        _out = is_same_dogma(tagged_dna1, tagged_rna1)
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, True)
    def test_public_04(self):
        self.meta['expression'] = "is_same_dogma(tagged_rna1, tagged_rna1)"
        self.meta['expected'] = str(True)
        
        _out = is_same_dogma(tagged_rna1, tagged_rna1)
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, True)
    def test_public_05(self):
        self.meta['expression'] = "is_same_dogma(tagged_rna1, tagged_dna2)"
        self.meta['expected'] = str(False)
        
        _out = is_same_dogma(tagged_rna1, tagged_dna2)
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, False)

class PrivateTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }
    def test_private_01(self):
        self.meta['expression'] = "get_tag_type(to_rna(tagged_dna1))"
        self.meta['expected'] = "'rna'"
        
        _out = get_tag_type(to_rna(tagged_dna1))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, 'rna')
    def test_private_02(self):
        self.meta['expression'] = "get_tag_type(to_dna(tagged_rna1))"
        self.meta['expected'] = "'dna'"
        
        _out = get_tag_type(to_dna(tagged_rna1))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, 'dna')

class EvaluationTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }


# Do not modify beyond this line
if __name__ == '__main__':
    unittest.main(
            testRunner=xmlrunner.XMLTestRunner(open('report.xml', 'wb'), outsuffix = ''),
            failfast=False,
            buffer=False,
            catchbreak=False)
