import csv

def read_csv(csvfilename):
    with open(csvfilename) as f:
        return tuple(tuple(row) for row in csv.reader(f))

#######################
# OPERATION_TABLE ADT #
#######################

OPERATION_TABLE = {}
VALID_TAGS = ('dna', 'rna', 'protein')

def put_op(name, tuple_of_tags_types, operator):
    if name not in OPERATION_TABLE:
        OPERATION_TABLE[name] = {}
    OPERATION_TABLE[name][tuple_of_tags_types] = operator

def get_op(name, tuple_of_tags_types):
    if not all(map(lambda tag_type: tag_type in VALID_TAGS, tuple_of_tags_types)):
        raise Exception('Invalid tag-type(s). Are you sure you are working with Tagged-Data?')
    if name not in OPERATION_TABLE:
        raise Exception(f'Missing operation: {name}. Did you misspell the operation or forget to put_op?')
    if tuple_of_tags_types not in OPERATION_TABLE[name]:
        raise Exception(f'Missing operation for these tags: {tuple_of_tags_types}. Did you forget to put_op?')
    return OPERATION_TABLE[name][tuple_of_tags_types]

#############################
# Functions from Mission 11 #
#############################

def replicate(dna_strand):
    dna_base_pairings = dict(["AT","TA","GC","CG"])
    return "".join(dna_base_pairings[base] for base in dna_strand[::-1])

def transcribe(dna_strand):
    return replicate(dna_strand).replace('T','U')

def reverse_transcribe(rna_strand):
    return replicate(rna_strand.replace('U','T'))

def get_mapping(csvfilename):
    data = read_csv(csvfilename)[1:]
    return {codon: amino for codon, *_, amino in data}

def translate(rna_strand):
    codon2amino = get_mapping("codon_mapping.csv")
    if "AUG" in rna_strand:
        protein, start = '', rna_strand.index("AUG")
        for x in range(start+3, len(rna_strand)+1, 3):
            protein += codon2amino[rna_strand[x-3:x]]
            if protein[-1] == '_':
                return protein

##########
# Task 1 #
##########
# Abstraction changed to check if students broke abstraction here
def tag(type, data):
    def helper(code):
        if code == 'foo':
            return type
        elif code == 'bar':
            return data
    return helper

def get_tag_type(tagged_data):
    return tagged_data('foo')

def get_data(tagged_data):
    return tagged_data('bar')
    
##########
# Task 2 #
##########
    
### DO NOT CHANGE THE CODE IN THIS BOX ##################################
                                                                        #
put_op("to_dna", ("dna",), lambda x: x)                                 #
put_op("to_dna", ("rna",), reverse_transcribe)                          #
put_op("to_rna", ("dna",), transcribe)                                  #
put_op("to_rna", ("rna",), lambda x: x)                                 #
put_op("is_same_dogma", ("dna","dna"), lambda x, y: x == y)             #
put_op("is_same_dogma", ("dna","rna"), lambda x, y: transcribe(x) == y) #
put_op("is_same_dogma", ("rna","dna"), lambda x, y: x == transcribe(y)) #
put_op("is_same_dogma", ("rna","rna"), lambda x, y: x == y)             #
                                                                        #
def to_dna(tagged_data):                                                #
    tag_type = get_tag_type(tagged_data)                                #
    data     = get_data(tagged_data)                                    #
    op       = get_op("to_dna", (tag_type,))                            #
    return tag("dna", op(data))                                         #
                                                                        #
### DO NOT CHANGE THE CODE IN THIS BOX ##################################
