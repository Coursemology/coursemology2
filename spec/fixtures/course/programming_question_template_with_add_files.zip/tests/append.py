# begin append code
a = Snake('A')
b = Snake('B')
c = Snake('C')
d = Snake('D')
e = Snake('E')
f = Snake('F')

# end append code