from collections import Counter
import unittest
# Needs xmlrunner: pip install unittest-xml-reporting
import xmlrunner
import sys

class PublicTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }
    def test_public_01(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        self.meta['expression'] = "aiko.bite(belle)"
        self.meta['expected'] = str(['Aiko bites Belle'])
        out = aiko.bite(belle)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Aiko bites Belle'])

    def test_public_02(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        self.meta['expression'] = "aiko.bite(belle)"
        self.meta['expected'] = str(['Aiko is already biting Belle'])
        out = aiko.bite(belle)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Aiko is already biting Belle'])

    def test_public_03(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        self.meta['expression'] = "belle.bite(charmi)"
        self.meta['expected'] = str(['Belle bites Charmi'])
        out = belle.bite(charmi)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Belle bites Charmi'])

    def test_public_04(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        self.meta['expression'] = "charmi.bite(aiko)"
        self.meta['expected'] = str(['Charmi bites Aiko', 'Ouroboros! Charmi->Aiko->Belle->Charmi'])
        out = charmi.bite(aiko)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Charmi bites Aiko', 'Ouroboros! Charmi->Aiko->Belle->Charmi'])

    def test_public_05(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        self.meta['expression'] = "duan.bite(enxuan)"
        self.meta['expected'] = str(['Duan bites Enxuan'])
        out = duan.bite(enxuan)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Duan bites Enxuan'])

    def test_public_06(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        self.meta['expression'] = "enxuan.bite(duan)"
        self.meta['expected'] = str(['Enxuan bites Duan', 'Ouroboros! Enxuan->Duan->Enxuan'])
        out = enxuan.bite(duan)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Enxuan bites Duan', 'Ouroboros! Enxuan->Duan->Enxuan'])

    def test_public_07(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        enxuan.bite(duan)
        self.meta['expression'] = "aiko.bite(duan)"
        self.meta['expected'] = str(['Aiko releases Belle', 'Uh oh! No more Ouroboros!', 'Enxuan releases Duan', 'Uh oh! No more Ouroboros!', 'Aiko bites Duan'])
        out = aiko.bite(duan)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Aiko releases Belle', 'Uh oh! No more Ouroboros!', 'Enxuan releases Duan', 'Uh oh! No more Ouroboros!', 'Aiko bites Duan'])

    def test_public_08(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        enxuan.bite(duan)
        aiko.bite(duan)
        self.meta['expression'] = "enxuan.bite(belle)"
        self.meta['expected'] = str(['Enxuan bites Belle', 'Ouroboros! Enxuan->Belle->Charmi->Aiko->Duan->Enxuan'])
        out = enxuan.bite(belle)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Enxuan bites Belle', 'Ouroboros! Enxuan->Belle->Charmi->Aiko->Duan->Enxuan'])

    def test_public_09(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        enxuan.bite(duan)
        aiko.bite(duan)
        enxuan.bite(belle)
        self.meta['expression'] = "charmi.bite(enxuan)"
        self.meta['expected'] = str(['Charmi releases Aiko', 'Uh oh! No more Ouroboros!', 'Duan releases Enxuan', 'Charmi bites Enxuan', 'Ouroboros! Charmi->Enxuan->Belle->Charmi'])
        out = charmi.bite(enxuan)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Charmi releases Aiko', 'Uh oh! No more Ouroboros!', 'Duan releases Enxuan', 'Charmi bites Enxuan', 'Ouroboros! Charmi->Enxuan->Belle->Charmi'])

    def test_public_10(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        enxuan.bite(duan)
        aiko.bite(duan)
        enxuan.bite(belle)
        charmi.bite(enxuan)
        self.meta['expression'] = "aiko.bite(aiko)"
        self.meta['expected'] = str(['Aiko releases Duan', 'Aiko bites Aiko', 'Ouroboros! Aiko->Aiko'])
        out = aiko.bite(aiko)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Aiko releases Duan', 'Aiko bites Aiko', 'Ouroboros! Aiko->Aiko'])

    def test_public_11(self):
        aiko   = Snake('Aiko')
        belle  = Snake('Belle')
        charmi = Snake('Charmi')
        duan   = Snake('Duan')
        enxuan = Snake('Enxuan')
        aiko.bite(belle)
        aiko.bite(belle)
        belle.bite(charmi)
        charmi.bite(aiko)
        duan.bite(enxuan)
        enxuan.bite(duan)
        aiko.bite(duan)
        enxuan.bite(belle)
        charmi.bite(enxuan)
        aiko.bite(aiko)
        self.meta['expression'] = "enxuan.bite(aiko)"
        self.meta['expected'] = str(['Enxuan releases Belle', 'Uh oh! No more Ouroboros!', 'Aiko releases Aiko', 'Uh oh! No more Ouroboros!', 'Enxuan bites Aiko'])
        out = enxuan.bite(aiko)
        self.meta['output'] = str(out)
        self.assertEqual(out, ['Enxuan releases Belle', 'Uh oh! No more Ouroboros!', 'Aiko releases Aiko', 'Uh oh! No more Ouroboros!', 'Enxuan bites Aiko'])

class PrivateTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }

class EvaluationTestsGrader(unittest.TestCase):
    def setUp(self):
        # clears the dictionary containing metadata for each test
        self.meta = { 'expression': '', 'expected': '', 'hint': '' }

    def test_evaluation_01(self):
        self.meta['expression'] = "a.bite(a)"
        self.meta['expected'] = "['A bites A', 'Ouroboros! A->A']"
        
        _out = str(a.bite(a))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['A bites A', 'Ouroboros! A->A']")

    def test_evaluation_02(self):
        self.meta['expression'] = "a.bite(b)"
        self.meta['expected'] = "['A releases A', 'Uh oh! No more Ouroboros!', 'A bites B']"
        
        _out = str(a.bite(b))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['A releases A', 'Uh oh! No more Ouroboros!', 'A bites B']")

    def test_evaluation_03(self):
        self.meta['expression'] = "c.bite(c)"
        self.meta['expected'] = "['C bites C', 'Ouroboros! C->C']"
        
        _out = str(c.bite(c))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['C bites C', 'Ouroboros! C->C']")

    def test_evaluation_04(self):
        self.meta['expression'] = "b.bite(c)"
        self.meta['expected'] = "['C releases C', 'Uh oh! No more Ouroboros!', 'B bites C']"
        
        _out = str(b.bite(c))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['C releases C', 'Uh oh! No more Ouroboros!', 'B bites C']")

    def test_evaluation_05(self):
        self.meta['expression'] = "c.bite(a)"
        self.meta['expected'] = "['C bites A', 'Ouroboros! C->A->B->C']"
        
        _out = str(c.bite(a))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['C bites A', 'Ouroboros! C->A->B->C']")

    def test_evaluation_06(self):
        self.meta['expression'] = "a.bite(c)"
        self.meta['expected'] = "['A releases B', 'Uh oh! No more Ouroboros!', 'B releases C', 'A bites C', 'Ouroboros! A->C->A']"
        
        _out = str(a.bite(c))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['A releases B', 'Uh oh! No more Ouroboros!', 'B releases C', 'A bites C', 'Ouroboros! A->C->A']")   

    def test_evaluation_07(self):
        self.meta['expression'] = "b.bite(d)"
        self.meta['expected'] = "['B bites D']"
        
        _out = str(b.bite(d))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['B bites D']")

    def test_evaluation_08(self):
        self.meta['expression'] = "e.bite(d)"
        self.meta['expected'] = "['B releases D', 'E bites D']"
        
        _out = str(e.bite(d))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['B releases D', 'E bites D']")

    def test_evaluation_09(self):
        self.meta['expression'] = "e.bite(f)"
        self.meta['expected'] = "['E releases D', 'E bites F']"
        
        _out = str(e.bite(f))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['E releases D', 'E bites F']")

    def test_evaluation_10(self):
        self.meta['expression'] = "f.bite(b)"
        self.meta['expected'] = "['F bites B']"
        
        _out = str(f.bite(b))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['F bites B']")

    def test_evaluation_11(self):
        self.meta['expression'] = "b.bite(b)"
        self.meta['expected'] = "['B bites D']"
        
        _out = str(b.bite(d))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['B bites D']")
    def test_evaluation_12(self):
        self.meta['expression'] = "d.bite(e)"
        self.meta['expected'] = "['D bites E', 'Ouroboros! D->E->F->B->D']"
        
        _out = str(d.bite(e))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['D bites E', 'Ouroboros! D->E->F->B->D']")

    def test_evaluation_13(self):
        self.meta['expression'] = "b.bite(a)"
        self.meta['expected'] = "['B releases D', 'Uh oh! No more Ouroboros!', 'C releases A', 'Uh oh! No more Ouroboros!', 'B bites A']"
        
        _out = str(b.bite(a))
        self.meta['output'] = "'" + _out + "'" if isinstance(_out, str) else _out
        self.assertEqual(_out, "['B releases D', 'Uh oh! No more Ouroboros!', 'C releases A', 'Uh oh! No more Ouroboros!', 'B bites A']")
        

# Do not modify beyond this line
if __name__ == '__main__':
    unittest.main(
            testRunner=xmlrunner.XMLTestRunner(open('report.xml', 'wb'), outsuffix = ''),
            failfast=False,
            buffer=False,
            catchbreak=False)
