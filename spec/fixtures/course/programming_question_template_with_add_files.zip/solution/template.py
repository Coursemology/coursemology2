class Snake:
    def __init__(self, name):
        self.name = name
        self.biting = None
        self.bitten = None

    def check_cycle(self): #helper function
        snakes = [self]
        while snakes[-1]:
            snakes.append(snakes[-1].biting)
            if snakes[-1] == self:
                return snakes
        return False

    def bite(self, other):
        if self.biting == other:
            return [f'{self.name} is already biting {other.name}']
        result = []
        if self.biting:
            release = self.biting
            result.append(f'{self.name} releases {release.name}')
            if self.check_cycle():
                result.append('Uh oh! No more Ouroboros!')
            release.bitten = None

        self.biting = None # Need to set to None to check cycle on other
        if other.bitten:
            biting_other = other.bitten
            result.append(f'{biting_other.name} releases {other.name}')
            if other.check_cycle():
                result.append('Uh oh! No more Ouroboros!')
            biting_other.biting = None
                
        other.bitten = self
        self.biting = other
        result += [f'{self.name} bites {other.name}']
        ouroboros = self.check_cycle()
        if ouroboros:
            result.append('Ouroboros! '
                       + '->'.join([snake.name for snake in ouroboros]))
        return result 
